# JARVIS Voice — fresh starter

এই Android starter project GitHub Actions দিয়ে debug APK তৈরি করার জন্য।

## বর্তমান ক্ষমতা
- Listen বোতাম চাপলে বাংলা voice recognition।
- একই বাক্যে Jarvis/জার্ভিস থাকলে শনাক্ত করার চেষ্টা।
- শুধু Jarvis বললে পরের নির্দেশ শোনে।
- YouTube খোলা, YouTube-এ গান সার্চ, Google search, camera intent।
- বাংলা TTS প্রতিক্রিয়া, ডিভাইসে ভাষা সমর্থিত হলে।

## সীমা — পরিষ্কারভাবে
- সবসময় background-এ wake word শোনা এখনো নেই; প্রথমে Listen চাপতে হয়।
- YouTube সার্চ খোলে, গান স্বয়ংক্রিয়ভাবে প্লে করার নিশ্চয়তা নেই।
- এটি এখনো পূর্ণ AI assistant নয়; কোনো LLM API যুক্ত নেই।
- এই সোর্স এখানে Android SDK দিয়ে compile/test করা হয়নি।

## ফোন থেকেই APK
1. GitHub-এ নতুন repository তৈরি করো (যেমন `jarvis-voice`).
2. ZIP extract করো এবং ZIP-এর ভেতরের সব ফাইল ও `.github` ফোল্ডার repository root-এ upload করো; শুধু ZIP আপলোড করো না।
3. Commit করে `Actions` ট্যাবে যাও।
4. `Build JARVIS APK` workflow run করো।
5. Build সফল হলে run খুলে `JARVIS-debug-APK` artifact download করো।
6. Artifact ZIP extract করে `app-debug.apk` install করো।

Build config: AGP 8.7.3, Kotlin 2.0.21, JDK 17, compileSdk 35, minSdk 26.

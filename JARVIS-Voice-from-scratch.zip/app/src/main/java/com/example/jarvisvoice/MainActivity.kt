package com.example.jarvisvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var listen: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 40, 28, 28)
        }
        layout.addView(TextView(this).apply { text = "JARVIS AI"; textSize = 30f; gravity = Gravity.CENTER })
        status = TextView(this).apply { text = "Listen চাপো, তারপর ‘Jarvis’ বলো"; textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 28, 0, 28) }
        listen = Button(this).apply { text = "Listen"; setOnClickListener { listenForWakeWord() } }
        layout.addView(status)
        layout.addView(listen)
        layout.addView(TextView(this).apply {
            text = "এই প্রাথমিক সংস্করণে Listen বোতাম চাপতে হবে। সবসময় background-এ শোনা এখনো চালু নয়।"
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 0)
        })
        setContentView(layout)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
    }

    private fun listenForWakeWord() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "ফোনে speech recognition পাওয়া যায়নি।"
            return
        }
        listen.isEnabled = false
        status.text = "শুনছি… ‘Jarvis’ বলো"
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { listen.isEnabled = true; status.text = "শোনা যায়নি। আবার Listen চাপো।" }
            override fun onResults(results: Bundle?) {
                listen.isEnabled = true
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                val s = spoken.lowercase(Locale.ROOT)
                status.text = "শুনেছি: $spoken"
                if (listOf("jarvis", "জার্ভিস", "জারভিস").none { s.contains(it) }) {
                    say("আমি Jarvis শব্দটি শুনতে পাইনি")
                    return
                }
                val command = s.replace("jarvis", "").replace("জার্ভিস", "").replace("জারভিস", "").trim()
                if (command.isBlank()) {
                    say("জি, বলুন")
                    listenForCommand()
                } else runCommand(command)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন: Jarvis")
        })
    }

    private fun listenForCommand() {
        status.text = "নির্দেশ শুনছি…"
        listen.isEnabled = false
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { listen.isEnabled = true; status.text = "নির্দেশ শোনা যায়নি। আবার চেষ্টা করো।" }
            override fun onResults(results: Bundle?) {
                listen.isEnabled = true
                runCommand(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase(Locale.ROOT))
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "আপনার নির্দেশ বলুন")
        })
    }

    private fun runCommand(c: String) {
        when {
            c.contains("youtube") || c.contains("ইউটিউব") -> open("https://www.youtube.com")
            c.contains("গান") || c.contains("বাজাও") || c.contains("চালাও") || c.contains("play music") || c.contains("play song") -> {
                val q = c.replace("গান চালাও", "").replace("গান বাজাও", "").replace("play music", "").replace("play song", "").trim().ifBlank { "Bangla songs" }
                open("https://www.youtube.com/results?search_query=${Uri.encode(q)}")
            }
            c.contains("google") || c.contains("গুগল") || c.contains("সার্চ") -> open("https://www.google.com/search?q=${Uri.encode(c)}")
            c.contains("camera") || c.contains("ক্যামেরা") -> try { startActivity(Intent("android.media.action.IMAGE_CAPTURE")) } catch (_: Exception) { status.text = "ক্যামেরা খোলা যায়নি" }
            else -> { status.text = "এই কমান্ড এখনো যোগ করা হয়নি: $c"; say("এই কমান্ড এখনো যোগ করা হয়নি") }
        }
    }
    private fun open(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); status.text = "খোলা হচ্ছে"; say("ঠিক আছে, খুলছি") }
        catch (_: Exception) { status.text = "খোলা যায়নি"; say("খোলা যায়নি") }
    }
    private fun say(s: String) { tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    override fun onInit(code: Int) { if (code == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD") }
    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}
